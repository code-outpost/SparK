---
name: html2pdf-cdp-verify
agent_created: true
description: Use when a user reports that an html2pdf.js / html2canvas-based PDF export is blank, truncated, or missing pages. Drives a real Chrome via Chrome DevTools Protocol (CDP) to capture the actual html2canvas canvas and generated PDF, avoiding false passes from browser native print-to-PDF.
---

# html2pdf 导出真实性验证

## 适用场景

- 用户报告“PDF 空白 / 只显示一部分 / 只有第一页”等 html2pdf.js 导出异常。
- 需要区分“浏览器原生打印管线完整”与“html2canvas 真实渲染管线完整”。
- 怀疑是浏览器缓存、html2canvas 高度测量、模板 CSS 或图片跨域导致的导出残缺。

## 核心思路

在真实 Chrome 中打开目标页面，通过 CDP 注入一段脚本：

1. 确保 `window.html2pdf` 已加载（如原页面是动态加载，则主动插入 `html2pdf.bundle.min.js`）。
2. 构造或复用简历/页面数据，生成要导出的 DOM holder。
3. 调用真实 `html2pdf().set(opt).from(holder).toCanvas()` 得到 canvas，读取其宽高。
4. 继续链式调用 `.toPdf()` 得到 jsPDF 实例，输出 base64 PDF。
5. 把 PDF 拉回本地，用 PyMuPDF 渲染成 PNG 逐页肉眼检查。

## 前置条件

- 本机安装 Google Chrome，路径示例：`C:/Program Files/Google/Chrome/Application/chrome.exe`。
- Python 虚拟环境已安装 `websocket-client` 与 `pymupdf`。
- 项目页面已暴露 `buildResumeHTML(data)` 或类似能生成导出 HTML 的函数。

## CDP 启动参数（关键）

```
chrome.exe --remote-debugging-port=9333 --remote-allow-origins=* --headless=new \
  --no-sandbox --disable-gpu --disable-dev-shm-usage --hide-scrollbars \
  --force-color-profile=srgb --window-size=1000,1400
```

- `--remote-allow-origins=*`：否则 WebSocket 握手会被 Chrome 以 403 拒绝。
- `--headless=new`：新版 headless 才能让 html2canvas 正常渲染。

## 连接会话（关键）

- `/json/version` 返回的是 browser 级 WebSocket，不能直接发 `Page.*` 命令。
- 必须先 `Target.createTarget({url})`，再 `Target.attachToTarget({targetId, flatten:true})` 拿到 `sessionId`。
- 之后的命令都带上该 `sessionId`。

## 页面加载前提

- 目标页面必须在 `app.js` 加载前包含 `<span id="clk">` 之类的时钟元素，否则 `app.js` 里的 `tick()` 会抛异常导致后续 API 未暴露。
- 等待 `window.SparKResume && window.RESUME_TEMPLATES` 都可用再开始导出。

## 诊断指标

- `holder.scrollHeight` 与 `.page.scrollHeight` 是否一致。
- canvas 高度是否约为 `scrollHeight * scale`。
- PDF 页数是否约为 `ceil(canvasHeight / (A4_px_height * scale))`。
- 若 `canvas` 高度明显小于内容高度，说明 html2canvas 量高失败，需在选项里显式传 `width/height`。
- 若页数偏少，说明 html2pdf 分页切片异常，检查 `jsPDF` 的 `format/orientation` 与 canvas 比例。

## 常见修复

- html2canvas 对 `position:fixed/absolute` 的 holder 容易量高为 0：
  ```js
  html2canvas: {
    scale: 2,
    width: w,
    height: h,
    x: 0, y: 0,
    scrollX: 0, scrollY: 0,
    windowWidth: 794,
    windowHeight: h,
    backgroundColor: '#ffffff',
    useCORS: true,
    allowTaint: true
  }
  ```
- 取高度时用 `Math.max(holder.scrollHeight, page.scrollHeight, page.getBoundingClientRect().height, holder.offsetHeight)`。
- 导出容器用 `position:fixed; left:0; top:0; width:794px; z-index:-1; pointer-events:none`，不遮挡、不参与文档流，但仍在 viewport 内让 html2canvas 正确栅格化。

## 资源

- `scripts/_export.js`：在页面内执行的 async IIFE 模板，可替换数据、捕获 canvas/PDF。
- `scripts/_cdp_test.py`：CDP 驱动脚本，启动 Chrome、导航、循环模板、保存 PDF、渲染 PNG。
